class Trade {
  constructor(type, symbol, amount, price, timestamp, reversed = false) {
    this.type = type;
    this.symbol = symbol;
    this.amount = amount;
    this.price = price;
    this.timestamp = timestamp || new Date().toISOString();
    this.reversed = reversed;
  }
}
module.exports = Trade;
