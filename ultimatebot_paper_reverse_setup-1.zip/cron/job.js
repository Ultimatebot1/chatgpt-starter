const runBot = require('../trader');
function startJob() {
  console.log("Starting scheduled job...");
  runBot();
}
startJob();
