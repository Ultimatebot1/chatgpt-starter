Ultimatebot Paper Trading with Reverse Mode

Includes:
- Paper trading toggle
- Reverse logic
- Simple trade simulation
